import React from "react";
import { Link } from "react-router-dom";
function Phone1()
{
    return(
        <div>
            <div>
                <h4>Battery performance:</h4>
                <p>6000mah</p>
                <p>Long time charger upto 14 hours</p>
            </div>
        </div>
    )
}
export default Phone1;