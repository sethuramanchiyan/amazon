import React from "react";


export const Users =
[
        {
            id:1,
            profilePicture:"/image/fb image/sachin.PNG",
            username:"sachin",
            decs:"Love the world",
            data:"5 mins ago",
            like:20,
            comment:10,
            userId:1

        },
        {
            id:2,
            profilePicture:"/image/fb image/watch.JPG",
            username:"Watch",
            decs:"Love the world",
            data:"45 mins ago",
            like:20,
            comment:10,
            userId:2

        },
        {
            id:3,
            photo:"/image/fb image/sachin.PNG",
            username:"sachin tendulkar",
            decs:"Love the world",
            data:"25 mins ago",
            like:20,
            comment:10,
            userId:3

        },
        {
            id:4,
            profilePicture:"/image/fb image/phone1.JPG",
            username:"Phone1",
            decs:"Love the world",
            data:"55 mins ago",
            like:20,
            comment:10,
            userId:4

        },
        {
            id:5,
            profilePicture:"/image/fb image/man.JPEG",
            username:"man",
            decs:"Love the world",
            data:"5 mins ago",
            like:20,
            comment:10,
            userId:5

        }
]

